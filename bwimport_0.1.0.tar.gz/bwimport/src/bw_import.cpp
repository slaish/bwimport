// [[Rcpp::depends(Rcpp)]]
#include <Rcpp.h>
#include "bigWig.h"  // must be available via Makevars include or bundled

using namespace Rcpp;

// Core C++ worker (unmangled name not required)
NumericVector readBigWigRegion_cpp(const std::string &bw_file, const std::string &chrom,
                                   int start, int end) {
    bigWigFile_t *bw = bwOpen(bw_file.c_str(), NULL, "r");
    if (!bw) stop("Cannot open BigWig file: %s", bw_file);

    bwOverlappingIntervals_t *intervals =
        bwGetValues(bw, chrom.c_str(), start, end, 1); // includeNA=1

    NumericVector vals(end - start + 1, 0.0);

    if (intervals != NULL) {
        for (uint32_t i = 0; i < intervals->l; ++i) {
            int idx = intervals->start[i] - start;
            if (idx >= 0 && idx < (int)vals.size()) {
                vals[idx] = intervals->value[i];
            }
        }
        bwDestroyOverlappingIntervals(intervals);
    }
    bwClose(bw);
    return vals;
}

// C wrapper exported with unmangled name for .Call()
extern "C" SEXP readBigWigRegion(SEXP bw_file_s, SEXP chrom_s, SEXP start_s, SEXP end_s) {
    std::string bw_file = as<std::string>(bw_file_s);
    std::string chrom = as<std::string>(chrom_s);
    int start = as<int>(start_s);
    int end = as<int>(end_s);

    NumericVector res = readBigWigRegion_cpp(bw_file, chrom, start, end);
    return Rcpp::wrap(res);
}

