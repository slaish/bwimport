#' Import BigWig region
#'
#' @param bw_file path or URL
#' @param chrom chromosome (eg "chr1")
#' @param start 1-based start
#' @param end 1-based end inclusive
#' @return numeric vector of length end-start+1
#' @export
bw_import <- function(bw_file, chrom, start, end) {
  stopifnot(is.character(bw_file), is.character(chrom))
  .Call("readBigWigRegion", as.character(bw_file), as.character(chrom),
        as.integer(start), as.integer(end))
}

